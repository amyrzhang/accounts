<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<div class="w100 h100 flex">
				<div class="flex-margin color-primary">测试界面</div>
			</div>
		</div>
	</div>
</template>

<script setup lang="ts" name="pagesFilteringDetails1">
// 此处需有内容（注释也得），否则缓存将失败
</script>
